public override object VisitDictionary(EasyBiteParser.DictionaryContext context)
        {
            var currentDictionary = new Dictionary<object, object>();

            foreach (var keyValue in context.keyvalue())
            {
                var key = Visit(keyValue.key());
                var value = keyValue.expression() != null ? Visit(keyValue.expression()) : Visit(keyValue.dictionary());

                currentDictionary[key] = value;
            }

            return currentDictionary;
        }


        public override object VisitKeyvalue(EasyBiteParser.KeyvalueContext context)
        {
            var key = VisitKey(context.key());
            var value = Visit(context.expression()) ?? Visit(context.dictionary());

            return new KeyValuePair<object, object>(key, value);
        }
        public override object VisitDictionary_access(EasyBiteParser.Dictionary_accessContext context)
        {
            var dictionaryName = context.DID().GetText();
            var dictionary = dictionaryStack[dictionaryName] as Dictionary<object, object>;

            if (dictionary == null)
            {
                throw new KeyNotFoundException(string.Format("Dictionary '{0}' not found.", dictionaryName));
            }
            else
            {

                foreach (var keyOrIndex in context.children)
                {
                    if (keyOrIndex is EasyBiteParser.KeyContext)
                    {
                        var key = VisitKey((EasyBiteParser.KeyContext)keyOrIndex);

                        if (!dictionary.ContainsKey(key))
                        {
                            throw new KeyNotFoundException(string.Format("Key '{0}' not found in dictionary '{1}'.", key, dictionaryName));
                        }

                        var value = dictionary[key];

                        if (value is Dictionary<object, object>)
                        {
                            dictionary = value as Dictionary<object, object>;
                        }
                        else
                        {
                            return value; // Return the value of the key
                        }
                    }
                }
            }

            throw new KeyNotFoundException("Invalid dictionary access.");  
        }



        public override object VisitKey(EasyBiteParser.KeyContext context)
        {
            if (context.STRING() != null)
            {
                return context.STRING().GetText().Substring(1, context.STRING().GetText().Length - 2);
                 // Remove the surrounding quotes
            }
            
            return null;
        }